package linda.shm;

import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;
import linda.Callback;
import linda.Linda;
import linda.Tuple;

/** Shared memory implementation of Linda. 
 * data are stored in an ArrayList
 * the data access is managed with monitors
 *
 * @author  Damien Kleiber and Philippe Leleux
 * @version 1.42
 */
public class CentralizedLinda implements Linda {

    private ArrayList<Tuple> list;		  //set containing all of the server's Tuple
    private BookList bookList;			  //object containing all tha callbacks registered
    private Lock moniteur;                //moniteur ensuring exclusive access to list
    private Condition newtuple;           //condition (signal, await) : add of a new Tuple

	/** Constructs a server Linda in shared memory by initializing
	 * the monitor (and a newTuple condition) 
	 * the ArrayList of Tuple with null
	 */
    public CentralizedLinda() {
        list= new ArrayList<Tuple>();
        this.moniteur = new ReentrantLock();
        this.newtuple = moniteur.newCondition ();
        this.bookList = new BookList();
    }

	/** Adds a tuple t to the tuplespace.
	 * @param t the tuple to add
	 */
    public void write(Tuple t) {
    	if (!bookList.notify(t)) {
            moniteur.lock();
            try {
        	list.add(t);
            System.out.println(t.toString()+ " added");
            newtuple.signalAll();
            } finally {
                moniteur.unlock();
            }
    	}
    }

	/** Returns a tuple matching the template and removes it from the tuplespace.
	 * Blocks if no corresponding tuple is found. 
	 * @param template an object Tuple model of the tuple searched
	 * @return a Tuple matching the template
	 */
    public  synchronized Tuple take(Tuple template) {
        moniteur.lock();
        Boolean loopCondition = true;
    	Tuple result = null;
        try {
            while (loopCondition) {
                System.out.println("boucle take");
		        for (int i = 0; i<list.size();i++) {
		            if (list.get(i).matches(template)) {
		                result = list.remove(i);
		                loopCondition = false;
		            }
		        }
				if (loopCondition) {
            		newtuple.await();
				}
			}
        } catch (InterruptedException ex) {
            Logger.getLogger(CentralizedLinda.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            moniteur.unlock();
        }
        return result;
    }

	/** Returns a tuple matching the template and leaves it in the tuplespace.
	 * Blocks if no corresponding tuple is found. 
	 * @param template an object Tuple model of the tuple searched
	 * @return a copy of the tuple matching the template if it exists or else null
	 */
    public  synchronized Tuple read(Tuple template) {
        Boolean loopCondition = true;
        Tuple result = null;
        moniteur.lock();
        try {
			while (loopCondition) {
				System.out.println("boucle read");
				for (Tuple t : list) {
			    if (t.matches(template)) 
			    	{
			    		result = t.deepclone();
			    		loopCondition = false;
			    	}
				}
				if (loopCondition) {
			    	newtuple.await();
				}
			}
		} catch (InterruptedException ex) {
			    Logger.getLogger(CentralizedLinda.class.getName()).log(Level.SEVERE, null, ex);
		} finally {
            moniteur.unlock();
        }
		return result;
    }

	/** Returns a tuple matching the template and removes it from the tuplespace.
	 * Returns null if none found. 
	 * @param template an object Tuple model of the tuple searched
	 * @return a Tuple matching the template if it exists or else null
	 */
    public Tuple tryTake(Tuple template) {
		Tuple result=null;
        moniteur.lock();
        try {
                for (int i = 0; i<list.size();i++) {
                    if (list.get(i).matches(template)) {
                        result=list.remove(i);
                    }
                }
        } finally {
            moniteur.unlock();
        }
        return result;
    }

	/** Returns a tuple matching the template and leaves it in the tuplespace.
	 * Returns null if none found. 
	 * @param template an object Tuple model of the tuple searched
	 * @return a copy of the tuple matching the template if it exists or else null
	 */
    public Tuple tryRead(Tuple template) {
    	Tuple result = null;
        moniteur.lock();
        try {
		    for (Tuple t : list) {
		        if (t.matches(template)) result=t.deepclone();
		    }
        } finally {
            moniteur.unlock();
        }
         return result;
    }

	/** Returns all the tuples matching the template and removes them from the tuplespace.
	 * Returns an empty collection if none found (never blocks).
	 * Note: there is no atomicity or consistency constraints between takeAll and other methods;
	 * for instance two concurrent takeAll with similar templates may split the tuples between the two results.
	 * @param template an object Tuple model of the tuple searched
	 * @return a collection of all the Tuple matching the template if there is any or else an empty collection 
	 */
    public synchronized Collection<Tuple> takeAll(Tuple template) {
        moniteur.lock(); 
        Collection<Tuple> collect= new ArrayList<Tuple>();
        try {
                for (int i = 0; i<list.size();i++) {
                    if (list.get(i).matches(template)) {
                        collect.add(list.remove(i));
                        i--; //<- Ca c'est super crade^^
                    }
                }
        } finally {
            moniteur.unlock();
        }
        return collect;
    }
    
	/** Returns all the tuples matching the template and leaves them in the tuplespace.
	 * Returns an empty collection if none found (never blocks).
	 * Note: there is no atomicity or consistency constraints between readAll and other methods;
	 * for instance (write([1]);write([2])) || readAll([?Integer]) may return only [2].
	 * @param template an object Tuple model of the tuple searched
	 * @return a collection of copies of all the Tuple matching the template if there is any or else an empty collection 
	 */
    public  synchronized Collection<Tuple> readAll(Tuple template) {
        moniteur.lock();
        Collection<Tuple> collect=new ArrayList<Tuple>();
        try {
		    for (Tuple t : list) {
		        if (t.matches(template)) collect.add(t.deepclone());
		    }
        } finally {
            moniteur.unlock();
        }
         return collect;
    }

	/** Registers a callback which will be called when a tuple matching the template appears.
	 * The found tuple is removed from the tuplespace.
	 * The callback is kept if it returns true, and is deregistered if it returns false. This is the only way to deregister a callback.
	 * Note that the callback may immediately fire if a matching tuple is already present. And as long as it returns true, it immediately fires multiple times.
	 * Beware: as the firing must wait for the return value of the callback, the callback must never block (see {@link AsynchronousCallback} class). 
	 * Callbacks are not ordered: if more than one may be fired, the chosen one is arbitrary.
	 * 
	 * @param template the filtering template.
	 * @param callback the callback to call if a matching tuple appears.
	 * @return
	 */
    public void eventRegister(Tuple template, Callback callback) {
		moniteur.lock();
        try {
        	bookList.register(template, this.list, ((MyCallback) callback));
        } finally {
            moniteur.unlock();
        }	
    }

	/** To debug, prints any information it wants (e.g. the tuples in tuplespace or the registered callbacks), prefixed by <code>prefix</code.
	 * @param prefix
	 */
    public void debug(String prefix) {
    	throw new UnsupportedOperationException("Not supported yet.");
    	// TO BE COMPLETED
    }



}
