package linda.shm;

import java.util.ArrayList;
import linda.Callback;
import linda.Tuple;

public class BookList {
    	private ArrayList<Callback> bookList; //set containing all the callBacks registered

    	public BookList () {
    		this.bookList=new ArrayList<Callback>();
    	}
    	
    	public void register(Tuple template, ArrayList<Tuple> list, Callback callback) {
	    	Boolean registerCallback=true;
	    	Boolean templatePresent=true;
	    	while(registerCallback&&templatePresent) {
			    for (Tuple t : list) {
			        if (t.matches(template)) {
			        	templatePresent=(((MyCallback)callback).getClient().getLinda().tryTake(template)!=null);
			        	if (templatePresent) {
			        		registerCallback=callback.call(template);
			        	}
			        }
			    }
	    	}
	    	if (registerCallback){
	    		bookList.add(callback);
	    	}
    	}	
	    
    	public boolean notify(Tuple template) {
    		Boolean result=false;
    		int i=0;
    		for(Callback c : bookList) {
    			if (((MyCallback)c).getTuple()==template) {
	    			result=true;
	    			c.call(template);
	    			bookList.remove(i);
	    			break;
    			}
    			i++;
    		}
    		return result;
    	}
}