package linda.shm;

import linda.Callback;
import linda.Tuple;

public class MyCallback implements Callback {

	private ProcessusClient client;
	private Tuple tuple;
	private int countdown;
	
	public MyCallback (ProcessusClient _client, Tuple _tuple) {
		this.client=_client;
		this.tuple=_tuple;
		this.countdown=2;
	}
	
	@Override
	public boolean call(Tuple t) {
		Boolean result=true;
		String oldMessage=client.getIhm().getText();
	    client.getIhm().setText("Par abonnement vous gagnez "+t.toString()+"    ");
		client.getIhm().setText(oldMessage);
		this.countdown--;
		if (countdown==0){
			result=false;
		}
		return result;
	}
	
	public ProcessusClient getClient() {
		return this.client;
	}
	
	public Tuple getTuple() {
		return this.tuple;
	}

}
